<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 6/8/2015
 * Time: 8:34 AM
 */
g5plus_get_template('comments');