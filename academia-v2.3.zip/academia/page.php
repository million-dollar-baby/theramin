<?php get_header(); ?>
<?php  g5plus_get_template('page');?>
<?php get_footer(); ?>