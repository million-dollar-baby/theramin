<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 6/8/2015
 * Time: 1:59 PM
 */
get_header();
g5plus_get_template( 'search');
get_footer();